package com.ca.directory.jxplorer.editor;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;



public class ocsprsaprivatekeyeditor extends basicbinaryeditor
{
    public ocsprsaprivatekeyeditor(Frame owner)
    {
        super(owner);
        // your special purpose code here...
    }
    // ... and here
}